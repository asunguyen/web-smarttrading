const nullthrows = (v) => {
    if (v == null) throw new Error("invalid arguments");
    return v;
}

function loadExtScript(src) {
    const script = document.createElement('script');
    script.src = src;
    script.onload = function () {
        console.log("SmartTrading for VPS SmartEasy v1.0");
        this.remove();
    }

    nullthrows(document.head || document.documentElement).appendChild(script);
}

loadExtScript(chrome.runtime.getURL('sp_loader.js'));